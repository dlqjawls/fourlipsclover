create table guide_request_form
(
    guide_request_form_id int auto_increment
        primary key,
    start_date            date                               not null,
    end_date              date                               not null,
    food_preference       varchar(255)                       not null,
    requirements          varchar(255)                       not null,
    taste_preference      varchar(255)                       not null,
    transportation        varchar(255)                       not null,
    created_at            datetime default CURRENT_TIMESTAMP not null,
    updated_at            datetime                           null,
    group_id              int                                null,
    constraint FKngf4w7w0hkp7ls56jo55milh3
        foreign key (group_id) references `group` (group_id)
);

INSERT INTO fourlipsclover.guide_request_form (guide_request_form_id, start_date, end_date, food_preference, requirements, taste_preference, transportation, created_at, updated_at, group_id) VALUES (89, '2025-04-19', '2025-04-20', '한식', '주말 하루동안 먹을 음식 추천좀요', '담백하게', '도보', '2025-04-10 22:37:12', '2025-04-10 22:37:12', 95);
INSERT INTO fourlipsclover.guide_request_form (guide_request_form_id, start_date, end_date, food_preference, requirements, taste_preference, transportation, created_at, updated_at, group_id) VALUES (91, '2025-04-12', '2025-04-13', '일식', '현지잉', '담백하게', '도보', '2025-04-11 02:26:55', '2025-04-11 02:26:55', 95);
INSERT INTO fourlipsclover.guide_request_form (guide_request_form_id, start_date, end_date, food_preference, requirements, taste_preference, transportation, created_at, updated_at, group_id) VALUES (92, '2025-04-19', '2025-04-26', '양식', 'ㅋ', '달콤하게', '택시/버스', '2025-04-11 02:28:04', '2025-04-11 02:28:04', 95);
INSERT INTO fourlipsclover.guide_request_form (guide_request_form_id, start_date, end_date, food_preference, requirements, taste_preference, transportation, created_at, updated_at, group_id) VALUES (93, '2025-04-19', '2025-04-20', '한식', '현지인 맛집 알려주세요', '담백하게', '렌터카', '2025-04-11 03:08:28', '2025-04-11 03:08:28', 95);
INSERT INTO fourlipsclover.guide_request_form (guide_request_form_id, start_date, end_date, food_preference, requirements, taste_preference, transportation, created_at, updated_at, group_id) VALUES (94, '2025-04-14', '2025-04-18', '일식', '맛있게1', '담백하게', '택시/버스', '2025-04-11 05:06:10', '2025-04-11 05:06:10', 101);
INSERT INTO fourlipsclover.guide_request_form (guide_request_form_id, start_date, end_date, food_preference, requirements, taste_preference, transportation, created_at, updated_at, group_id) VALUES (95, '2025-04-12', '2025-04-14', '중식', '하잉', '달콤하게', '렌터카', '2025-04-11 06:54:03', '2025-04-11 06:54:03', 95);
