create table plan_schedule
(
    place_id         int                                not null,
    plan_id          int                                not null,
    plan_schedule_id int auto_increment
        primary key,
    created_at       datetime default CURRENT_TIMESTAMP not null,
    updated_at       datetime(6)                        null,
    visit_at         datetime(6)                        not null,
    notes            varchar(255)                       null,
    constraint FK9au7s8xntat6jugdkwkbtcl2k
        foreign key (place_id) references restaurant (restaurant_id),
    constraint FKd10xqkgr0rtt4rlfglsa13y45
        foreign key (plan_id) references plan (plan_id)
);

INSERT INTO fourlipsclover.plan_schedule (place_id, plan_id, plan_schedule_id, created_at, updated_at, visit_at, notes) VALUES (43, 42, 31, '2025-04-10 20:09:13', null, '2025-04-19 19:00:00.000000', null);
INSERT INTO fourlipsclover.plan_schedule (place_id, plan_id, plan_schedule_id, created_at, updated_at, visit_at, notes) VALUES (42, 42, 32, '2025-04-10 20:11:20', null, '2025-04-19 13:30:00.000000', null);
INSERT INTO fourlipsclover.plan_schedule (place_id, plan_id, plan_schedule_id, created_at, updated_at, visit_at, notes) VALUES (375, 42, 33, '2025-04-10 20:13:01', null, '2025-04-19 15:00:00.000000', null);
INSERT INTO fourlipsclover.plan_schedule (place_id, plan_id, plan_schedule_id, created_at, updated_at, visit_at, notes) VALUES (32, 44, 35, '2025-04-11 03:14:49', null, '2025-04-17 12:00:00.000000', null);
INSERT INTO fourlipsclover.plan_schedule (place_id, plan_id, plan_schedule_id, created_at, updated_at, visit_at, notes) VALUES (32, 42, 36, '2025-04-11 03:57:36', null, '2025-04-11 18:00:00.000000', null);
INSERT INTO fourlipsclover.plan_schedule (place_id, plan_id, plan_schedule_id, created_at, updated_at, visit_at, notes) VALUES (32, 46, 37, '2025-04-11 05:46:36', null, '2025-04-22 17:30:00.000000', '막창만 먹어도 꿀맛');
INSERT INTO fourlipsclover.plan_schedule (place_id, plan_id, plan_schedule_id, created_at, updated_at, visit_at, notes) VALUES (2, 46, 38, '2025-04-11 05:47:00', null, '2025-04-22 16:00:00.000000', null);
INSERT INTO fourlipsclover.plan_schedule (place_id, plan_id, plan_schedule_id, created_at, updated_at, visit_at, notes) VALUES (1, 46, 39, '2025-04-11 05:47:21', null, '2025-04-22 08:50:00.000000', null);
