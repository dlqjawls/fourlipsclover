create table payment_item
(
    payment_item_id int auto_increment
        primary key,
    item_name       varchar(255) not null,
    quantity        varchar(255) not null,
    total_amount    varchar(255) not null
);

INSERT INTO fourlipsclover.payment_item (payment_item_id, item_name, quantity, total_amount) VALUES (1, '현지인 매칭 수수료', '1', '2000');
