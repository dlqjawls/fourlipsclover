create table expense_participant
(
    expense_participant_id bigint auto_increment
        primary key,
    created_at             datetime(6) null,
    updated_at             datetime(6) null,
    expense_id             bigint      null,
    member_id              bigint      null,
    constraint FKae42i6i4gjn6nkph6vkidrgft
        foreign key (expense_id) references expense (expense_id),
    constraint FKcvglix978mkrabnd6au63w8q5
        foreign key (member_id) references member (member_id)
);

INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (102, '2025-04-11 02:44:06.523041', '2025-04-11 02:44:06.523059', 25, 3962115782);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (103, '2025-04-11 02:44:06.525060', '2025-04-11 02:44:06.525073', 25, 3971753771);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (104, '2025-04-11 02:44:06.527524', '2025-04-11 02:44:06.527537', 25, 4200022075);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (105, '2025-04-11 02:44:06.532165', '2025-04-11 02:44:06.532177', 26, 3962115782);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (106, '2025-04-11 02:44:06.534251', '2025-04-11 02:44:06.534264', 26, 3971753771);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (107, '2025-04-11 02:44:06.536174', '2025-04-11 02:44:06.536187', 26, 4200022075);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (108, '2025-04-11 02:44:06.540011', '2025-04-11 02:44:06.540022', 27, 3962115782);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (109, '2025-04-11 02:44:06.541614', '2025-04-11 02:44:06.541623', 27, 3971753771);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (110, '2025-04-11 02:44:06.544025', '2025-04-11 02:44:06.544037', 27, 4200022075);
INSERT INTO fourlipsclover.expense_participant (expense_participant_id, created_at, updated_at, expense_id, member_id) VALUES (114, '2025-04-11 03:12:20.371685', '2025-04-11 03:12:20.371707', 28, 3962115782);
