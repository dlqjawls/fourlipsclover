create table member_review_tag
(
    avg_confidence       float  null,
    frequency            int    null,
    tag_id               bigint null,
    member_id            bigint null,
    member_review_tag_id bigint auto_increment
        primary key,
    constraint FKfce5cg5dj0irxlnqvd4o2et0f
        foreign key (member_id) references member (member_id),
    constraint FKnpcej2fxc9fdu6cwm4pga8saq
        foreign key (tag_id) references tag (tag_id)
);

INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (55.9808, 18, 1, 4004582987, 1);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.0565, 21, 55, 4004582987, 2);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.393, 16, 63, 4004582987, 3);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.0864, 11, 3, 4004582987, 4);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (55.1968, 7, 1, 3971753771, 5);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (54.7195, 7, 63, 3971753771, 6);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.0348, 6, 6, 3971753771, 7);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (55.6962, 4, 17, 3971753771, 8);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (56.1963, 2, 58, 3971753771, 9);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.9092, 4, 55, 3971753771, 10);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.3052, 1, 70, 3971753771, 11);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (60.4094, 1, 66, 3971753771, 12);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.2245, 5, 66, 4004582987, 13);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (54.327, 1, 88, 3971753771, 14);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (54.0975, 1, 11, 3971753771, 15);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.6237, 1, 12, 3971753771, 16);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.2291, 1, 24, 3971753771, 17);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (61.946, 12, 53, 4004582987, 18);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (61.8975, 1, 62, 3971753771, 19);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (59.2401, 12, 17, 4004582987, 20);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (54.5733, 2, 94, 4004582987, 21);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (63.4624, 1, 26, 4200022075, 22);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (61.4754, 3, 17, 4200022075, 23);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (61.6226, 1, 11, 4200022075, 24);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (56.6511, 2, 53, 4200022075, 25);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (60.052, 1, 44, 4200022075, 26);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.5367, 4, 63, 3967305143, 27);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (57.5223, 1, 70, 3967305143, 28);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (71.3533, 1, 53, 3971753771, 29);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (56.6053, 2, 55, 3967305143, 30);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (56.4043, 3, 1, 3967305143, 31);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (56.3599, 3, 6, 3967305143, 32);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.0632, 1, 3, 3967305143, 33);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (55.9715, 3, 55, 4200022075, 34);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (58.9543, 1, 63, 4200022075, 35);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (56.6472, 1, 1, 4200022075, 36);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.4433, 1, 3, 4200022075, 37);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.0198, 1, 2, 4200022075, 38);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (66.5474, 2, 17, 3962115782, 39);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (55.6196, 1, 53, 3962115782, 40);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.2631, 1, 88, 3962115782, 41);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.2433, 1, 11, 3962115782, 42);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (50.9706, 1, 65, 3967305143, 43);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (56.3757, 3, 3, 3971753771, 44);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (54.5437, 3, 2, 3971753771, 45);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.3024, 1, 47, 3971753771, 46);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.0246, 1, 25, 4200022075, 47);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.5042, 1, 88, 4200022075, 48);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (54.7465, 1, 70, 4200022075, 49);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (50.5789, 1, 47, 4200022075, 50);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (67.0985, 1, 1, 3962115782, 51);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (62.214, 1, 3, 3962115782, 52);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (57.6204, 1, 2, 3962115782, 53);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (56.2051, 1, 6, 3962115782, 54);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (55.1482, 1, 63, 3962115782, 55);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.9928, 7, 2, 4004582987, 56);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.2264, 1, 24, 4004582987, 57);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (48.5525, 5, 47, 4004582987, 58);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.246, 1, 20, 4004582987, 59);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.3617, 2, 77, 4004582987, 60);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.4915, 5, 88, 4004582987, 61);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (49.9521, 1, 85, 4004582987, 62);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.3112, 3, 11, 4004582987, 63);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.1307, 5, 6, 4004582987, 64);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (48.5278, 4, 70, 4004582987, 65);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (54.8498, 1, 31, 4004582987, 66);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (50.2218, 1, 12, 4004582987, 67);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (43.6078, 1, 7, 4004582987, 68);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.7588, 1, 44, 4004582987, 69);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.0287, 2, 25, 4004582987, 70);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (55.3388, 1, 58, 4004582987, 71);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.9251, 2, 90, 4004582987, 72);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (57.6358, 1, 46, 4004582987, 73);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (52.3571, 1, 29, 4004582987, 74);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (54.773, 1, 53, 3967305143, 75);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (51.8738, 1, 7, 3967305143, 76);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (53.0803, 1, 6, 4210895928, 77);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (50.5705, 1, 63, 4210895928, 78);
INSERT INTO fourlipsclover.member_review_tag (avg_confidence, frequency, tag_id, member_id, member_review_tag_id) VALUES (50.481, 1, 1, 4210895928, 79);
