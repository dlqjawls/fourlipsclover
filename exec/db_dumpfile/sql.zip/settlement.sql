create table settlement
(
    settlement_id     int auto_increment
        primary key,
    created_at        datetime(6)                                              null,
    end_date          datetime(6)                                              not null,
    settlement_status enum ('CANCELED', 'COMPLETED', 'IN_PROGRESS', 'PENDING') not null,
    start_date        datetime(6)                                              not null,
    updated_at        datetime(6)                                              null,
    plan_id           int                                                      null,
    member_id         bigint                                                   null,
    constraint UK3m5sl43hp6oxfjfjq1v62mb0o
        unique (plan_id),
    constraint FKfdjrqpe345juemsaehk08cfdf
        foreign key (plan_id) references plan (plan_id),
    constraint FKqmsiw656x8um90ysgl3dd2jo0
        foreign key (member_id) references member (member_id)
);

INSERT INTO fourlipsclover.settlement (settlement_id, created_at, end_date, settlement_status, start_date, updated_at, plan_id, member_id) VALUES (43, '2025-04-11 01:39:45.215099', '2025-04-21 00:00:00.000000', 'COMPLETED', '2025-04-19 00:00:00.000000', '2025-04-11 03:12:36.042750', 42, 3962115782);
INSERT INTO fourlipsclover.settlement (settlement_id, created_at, end_date, settlement_status, start_date, updated_at, plan_id, member_id) VALUES (45, '2025-04-11 03:14:30.718187', '2025-04-20 00:00:00.000000', 'PENDING', '2025-04-17 00:00:00.000000', '2025-04-11 03:14:30.718207', 44, 3967305143);
INSERT INTO fourlipsclover.settlement (settlement_id, created_at, end_date, settlement_status, start_date, updated_at, plan_id, member_id) VALUES (46, '2025-04-11 05:03:09.825130', '2025-04-18 00:00:00.000000', 'PENDING', '2025-04-15 00:00:00.000000', '2025-04-11 05:03:09.825358', 45, 4200022075);
INSERT INTO fourlipsclover.settlement (settlement_id, created_at, end_date, settlement_status, start_date, updated_at, plan_id, member_id) VALUES (47, '2025-04-11 05:44:14.496102', '2025-04-26 00:00:00.000000', 'PENDING', '2025-04-22 00:00:00.000000', '2025-04-11 05:44:14.496118', 46, 3967305143);
