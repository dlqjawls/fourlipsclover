create table locals_proposal
(
    match_id       int          not null,
    proposal_id    int auto_increment
        primary key,
    description    varchar(255) null,
    recommend_menu varchar(255) not null,
    constraint UKll4li5rm156oot4ebf6iu75hk
        unique (match_id),
    constraint FK5snbhkdeo1a1y95l612bt0mev
        foreign key (match_id) references `match` (match_id)
);

