create table group_member
(
    group_id  int                                not null,
    joined_at datetime default CURRENT_TIMESTAMP not null,
    member_id bigint                             not null,
    primary key (group_id, member_id),
    constraint FKfv4bftflj5osjp2l4e5kn0ogd
        foreign key (member_id) references member (member_id),
    constraint FKmt03j7oar5slk1k1rqv6f4eau
        foreign key (group_id) references `group` (group_id)
);

INSERT INTO fourlipsclover.group_member (group_id, joined_at, member_id) VALUES (95, '2025-04-10 16:00:55', 3962115782);
INSERT INTO fourlipsclover.group_member (group_id, joined_at, member_id) VALUES (95, '2025-04-10 23:46:06', 3971753771);
INSERT INTO fourlipsclover.group_member (group_id, joined_at, member_id) VALUES (95, '2025-04-10 23:46:06', 4004582987);
INSERT INTO fourlipsclover.group_member (group_id, joined_at, member_id) VALUES (95, '2025-04-10 23:46:06', 4200022075);
INSERT INTO fourlipsclover.group_member (group_id, joined_at, member_id) VALUES (100, '2025-04-11 03:14:21', 3967305143);
INSERT INTO fourlipsclover.group_member (group_id, joined_at, member_id) VALUES (101, '2025-04-11 05:03:58', 3962115782);
INSERT INTO fourlipsclover.group_member (group_id, joined_at, member_id) VALUES (101, '2025-04-11 05:02:46', 4200022075);
INSERT INTO fourlipsclover.group_member (group_id, joined_at, member_id) VALUES (104, '2025-04-11 05:42:06', 3967305143);
