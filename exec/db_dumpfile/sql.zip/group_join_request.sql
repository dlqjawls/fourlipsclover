create table group_join_request
(
    group_id      int                                not null,
    id            int auto_increment
        primary key,
    member_id     bigint                             not null,
    requested_at  datetime default CURRENT_TIMESTAMP not null,
    updated_at    datetime(6)                        null,
    admin_comment varchar(255)                       null,
    status        varchar(255)                       not null,
    token         varchar(255)                       not null,
    constraint FK43hbsvomloubejlcr18058ms7
        foreign key (group_id) references `group` (group_id),
    constraint FKdegv3u04mfsvxkblxcnnwi7h5
        foreign key (member_id) references member (member_id)
);

INSERT INTO fourlipsclover.group_join_request (group_id, id, member_id, requested_at, updated_at, admin_comment, status, token) VALUES (95, 14, 4200022075, '2025-04-10 23:45:52', '2025-04-10 23:46:06.008604', '가입을 승인했습니다.', 'ACCEPTED', '649c2d14-929b-41c9-9889-adfddf05b6cf');
INSERT INTO fourlipsclover.group_join_request (group_id, id, member_id, requested_at, updated_at, admin_comment, status, token) VALUES (101, 15, 3962115782, '2025-04-11 05:03:42', '2025-04-11 05:03:57.984193', '가입을 승인했습니다.', 'ACCEPTED', 'e4b1cef0-3722-4b15-851c-557a12e8e8c6');
