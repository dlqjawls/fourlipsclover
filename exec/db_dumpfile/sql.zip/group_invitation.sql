create table group_invitation
(
    group_id   int                                not null,
    id         int auto_increment
        primary key,
    created_at datetime default CURRENT_TIMESTAMP not null,
    expired_at datetime(6)                        not null,
    updated_at datetime(6)                        null,
    token      varchar(255)                       not null,
    constraint UKrf228mo6g7wocvrsn7jsbe8lp
        unique (token)
);

INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (29, 1, '2025-04-04 05:07:21', '2025-04-05 05:07:21.854951', null, 'f824e568-2efa-493b-aa35-29231dbbc982');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (29, 5, '2025-04-05 11:12:46', '2025-04-06 11:12:46.826055', null, '7a0892d7-ec81-4e09-8fcc-932eca12dbb3');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (11, 6, '2025-04-05 11:18:23', '2025-04-06 11:18:23.187581', null, '6ab2d34d-f745-4990-90c2-78e2b52ceb61');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 7, '2025-04-05 11:27:45', '2025-04-06 11:27:45.484124', null, 'f0875c68-226d-4566-a407-2b2e8d0451c9');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 8, '2025-04-05 11:28:59', '2025-04-06 11:28:59.811045', null, 'c9bc855b-2748-4708-9368-7218cc58f8df');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 9, '2025-04-05 11:32:31', '2025-04-06 11:32:31.609116', null, 'e284dd47-73ad-46a1-926b-111486943e3c');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 10, '2025-04-05 12:09:36', '2025-04-06 12:09:36.098617', null, 'a6c3b485-fcae-4e04-b160-7a98f116912f');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 11, '2025-04-05 12:22:03', '2025-04-06 12:22:03.516928', null, '47fa7042-df36-486f-a1a9-18975e1fb056');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 12, '2025-04-05 12:26:48', '2025-04-06 12:26:48.075262', null, '91f4c833-9c4c-49ba-9efd-7414ddf0d0f8');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 13, '2025-04-05 12:27:05', '2025-04-06 12:27:05.146588', null, '8be185e9-16c0-41df-91d3-2bb92a9f9ccd');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 14, '2025-04-05 12:30:39', '2025-04-06 12:30:39.300444', null, 'c84415ee-eed4-4129-95d5-c2fac3c0ff0d');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 15, '2025-04-05 12:35:47', '2025-04-06 12:35:47.100032', null, 'add06c30-9ff9-48e2-b6cf-13828d39e9de');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 16, '2025-04-05 12:39:00', '2025-04-06 12:39:00.261624', null, '01e15267-14be-4f3b-a1ae-f6e4e1798551');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 17, '2025-04-05 12:46:23', '2025-04-06 12:46:23.282207', null, '9e281104-da52-44c8-827f-3ec09a9a27c6');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 18, '2025-04-05 12:47:20', '2025-04-06 12:47:20.300820', null, '580181db-2fb5-4449-ae2c-ade7c65fef7e');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 19, '2025-04-05 12:48:07', '2025-04-06 12:48:07.882626', null, 'abc7ee0d-1b5d-4611-bfa4-b1b91b4bcc64');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 20, '2025-04-05 14:12:32', '2025-04-06 14:12:32.576205', null, 'bcc0c21a-145d-46d9-b7ae-d7a43efae88e');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (1, 21, '2025-04-05 14:23:56', '2025-04-06 14:23:56.319486', null, '40550196-b6fb-4831-ac05-e36921f66f22');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (42, 29, '2025-04-06 12:34:13', '2025-04-07 12:34:13.972223', null, 'aca7c728-f15e-4311-9687-57ad6d373603');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (42, 30, '2025-04-06 15:55:39', '2025-04-07 15:55:39.308043', null, '4a47da4c-57f5-4989-8cb8-d09b9eb6359c');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (46, 31, '2025-04-07 01:48:30', '2025-04-08 01:48:30.626227', null, '908534cf-d001-40dd-a203-76b0cbaeedfe');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (42, 32, '2025-04-07 05:01:11', '2025-04-08 05:01:11.495727', null, '59580241-4714-4ec6-a9f2-23abbea538b7');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (42, 33, '2025-04-07 05:01:13', '2025-04-08 05:01:13.857621', null, 'c7c61265-5f76-453b-bdf9-aaf04df54b62');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (45, 48, '2025-04-07 14:00:56', '2025-04-08 14:00:56.972868', null, 'f18546fb-71ce-4d89-8b4d-2e180f22109d');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (45, 49, '2025-04-07 14:02:50', '2025-04-08 14:02:50.829546', null, 'a0df6757-71b1-4fc5-8296-75150909f378');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (51, 51, '2025-04-07 14:05:40', '2025-04-08 14:05:40.094594', null, '7061a49e-1542-43eb-a88e-d53c6d7bb241');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (51, 52, '2025-04-07 14:06:16', '2025-04-08 14:06:16.717417', null, '331f9df4-ed53-447d-a468-d162ed8265a2');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (51, 53, '2025-04-07 14:35:18', '2025-04-08 14:35:18.396194', null, '7d782f87-c964-43ab-b47e-6b51922608aa');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (51, 54, '2025-04-07 16:17:57', '2025-04-08 16:17:57.903585', null, '15811798-1594-4ea0-8214-3120117180c9');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (45, 57, '2025-04-08 03:02:59', '2025-04-09 03:02:59.272256', null, '5edcf436-e36e-46f5-9f1c-dec405c6563c');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (46, 58, '2025-04-09 01:44:09', '2025-04-10 01:44:09.068197', null, '3786c647-8e70-4e6b-b32c-625738dd9969');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (46, 59, '2025-04-09 01:44:14', '2025-04-10 01:44:14.737545', null, '673f5879-e0ba-4567-a252-16335e5f4661');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (46, 60, '2025-04-09 01:44:27', '2025-04-10 01:44:27.513944', null, '0738cd69-b8a0-4415-b71f-1a3258f117be');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (45, 61, '2025-04-09 02:20:04', '2025-04-10 02:20:04.599499', null, '3096f294-d324-4417-bbb1-3006d7fc4771');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (45, 62, '2025-04-09 02:20:56', '2025-04-10 02:20:56.491596', null, '90a127ae-168a-402a-861e-f5c5867a04a3');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (45, 63, '2025-04-09 02:22:08', '2025-04-10 02:22:08.156005', null, '95864528-982d-4a13-adbb-4eb2eac568b8');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (58, 64, '2025-04-09 02:28:08', '2025-04-10 02:28:08.567247', null, 'f954ca11-c5a8-4cc6-864a-75b50d028680');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (9, 65, '2025-04-09 06:12:33', '2025-04-10 06:12:33.432158', null, '834c2cb8-7108-439c-ac8d-dc887a043a05');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (58, 66, '2025-04-10 00:24:23', '2025-04-11 00:24:23.914430', null, 'a55599a3-7b71-4cd4-a4bf-b6e52162ab6f');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (58, 67, '2025-04-10 00:27:04', '2025-04-11 00:27:04.103591', null, 'b134f9a3-d36e-4051-a30f-08be77c34fff');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (42, 68, '2025-04-10 00:43:17', '2025-04-11 00:43:17.841835', null, '1b40b0cb-e075-40c3-a5f8-abe792823362');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (61, 69, '2025-04-10 01:09:49', '2025-04-11 01:09:49.699244', null, 'ac8ef257-8872-4a6d-ad01-f4d409a276b7');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (88, 70, '2025-04-10 01:16:27', '2025-04-11 01:16:27.885422', null, '1df19785-1f75-48c6-ac80-ae44b5c53534');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (88, 71, '2025-04-10 01:17:39', '2025-04-11 01:17:39.536399', null, 'b51decff-6286-4e93-8e5f-0b05b24bf62e');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (88, 72, '2025-04-10 02:42:21', '2025-04-11 02:42:21.406552', null, '1362c192-05c6-4d49-b161-506f6fd5a648');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (88, 73, '2025-04-10 02:43:47', '2025-04-11 02:43:47.812991', null, '757766d8-d7f1-4a1d-93a8-aeccae15301b');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (92, 74, '2025-04-10 08:04:36', '2025-04-11 08:04:36.307165', null, 'de84c4ec-2abe-46dd-a45c-2952ab3dbad7');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (60, 75, '2025-04-10 08:10:14', '2025-04-11 08:10:14.434124', null, '9614830d-c147-4bb5-af89-a8dc11b5e353');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (9, 76, '2025-04-10 13:13:41', '2025-04-11 13:13:41.266899', null, '325deca6-9cbd-4ae1-8a7f-91771faa9f8d');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (93, 77, '2025-04-10 13:18:50', '2025-04-11 13:18:50.198459', null, '5f29bb33-57cd-44cb-919d-2a657c15b2b8');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (93, 78, '2025-04-10 13:19:00', '2025-04-11 13:19:00.467899', null, 'be9a4ce1-86a6-4e2d-80f2-9011e575a4bc');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (95, 79, '2025-04-10 16:01:04', '2025-04-11 16:01:04.449762', null, 'aec001aa-340f-4410-8a8b-065f81f97bae');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (95, 80, '2025-04-10 20:03:36', '2025-04-11 20:03:36.623393', null, '649c2d14-929b-41c9-9889-adfddf05b6cf');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (95, 81, '2025-04-11 00:24:06', '2025-04-12 00:24:06.380859', null, 'de2295f6-03c8-4785-934c-7babb886f3e2');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (95, 82, '2025-04-11 01:42:27', '2025-04-12 01:42:27.486077', null, '13c944ee-8165-4c02-b3c8-36f6f7d43433');
INSERT INTO fourlipsclover.group_invitation (group_id, id, created_at, expired_at, updated_at, token) VALUES (101, 83, '2025-04-11 05:03:13', '2025-04-12 05:03:13.579909', null, 'e4b1cef0-3722-4b15-851c-557a12e8e8c6');
