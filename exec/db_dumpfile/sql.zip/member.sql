create table member
(
    age           int                                  null,
    is_withdrawal tinyint(1) default 0                 null,
    trust_score   float      default 0                 null,
    created_at    timestamp  default CURRENT_TIMESTAMP null,
    member_id     bigint                               not null
        primary key,
    updated_at    timestamp                            null,
    withdrawal_at timestamp                            null,
    profile_url   varchar(1000)                        null,
    email         varchar(255)                         not null,
    nickname      varchar(255)                         not null,
    gender        enum ('female', 'male')              null
);

INSERT INTO fourlipsclover.member (age, is_withdrawal, trust_score, created_at, member_id, updated_at, withdrawal_at, profile_url, email, nickname, gender) VALUES (null, 0, 2, '2025-03-31 01:21:35', 3962115782, null, null, 'http://k.kakaocdn.net/dn/bmWSHS/btsJSnpYmCg/O2MmzM3nFVYUBc7SdR0BlK/img_640x640.jpg', 'sejong980929nini@gmail.com', '박시현', 'female');
INSERT INTO fourlipsclover.member (age, is_withdrawal, trust_score, created_at, member_id, updated_at, withdrawal_at, profile_url, email, nickname, gender) VALUES (null, 0, 0, '2025-03-31 01:25:48', 3963528811, null, null, '9afcc993-3cf0-4e90-838a-7e11db227735_scaled_Screenshot_20250406_121020.jpg', 'lbjtest@kakao.com', 'test', 'male');
INSERT INTO fourlipsclover.member (age, is_withdrawal, trust_score, created_at, member_id, updated_at, withdrawal_at, profile_url, email, nickname, gender) VALUES (null, 0, 2, '2025-03-31 02:25:21', 3967305143, null, null, 'd2beda6a-b7c8-4140-947b-6a48d0264757_scaled_다운로드 (1).jpg', 'yhj0566@naver.com', '윤희준', 'male');
INSERT INTO fourlipsclover.member (age, is_withdrawal, trust_score, created_at, member_id, updated_at, withdrawal_at, profile_url, email, nickname, gender) VALUES (null, 0, 2, '2025-04-02 06:52:32', 3971753771, null, null, 'http://k.kakaocdn.net/dn/KlftL/btsJHQssFeg/jfSYHKx0yhezKL35Pv5qp0/img_640x640.jpg', 'aruesin2@naver.com', '김성현', 'male');
INSERT INTO fourlipsclover.member (age, is_withdrawal, trust_score, created_at, member_id, updated_at, withdrawal_at, profile_url, email, nickname, gender) VALUES (null, 0, 2, '2025-03-31 01:21:35', 4004582987, null, null, 'http://k.kakaocdn.net/dn/cadWgk/btsMWH7IywU/PL7do5l6Abhzu1LpHB6j7K/img_640x640.jpg', 'tokkuri@kakao.com', '이채원', 'female');
INSERT INTO fourlipsclover.member (age, is_withdrawal, trust_score, created_at, member_id, updated_at, withdrawal_at, profile_url, email, nickname, gender) VALUES (null, 0, 2, '2025-04-03 01:57:53', 4200022075, null, null, 'http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg', 'dlqjawls@gmail.com', '이범진', 'male');
INSERT INTO fourlipsclover.member (age, is_withdrawal, trust_score, created_at, member_id, updated_at, withdrawal_at, profile_url, email, nickname, gender) VALUES (null, 0, 0, '2025-04-03 13:02:49', 4200936557, null, null, '', '', '새로운 사용자', 'male');
INSERT INTO fourlipsclover.member (age, is_withdrawal, trust_score, created_at, member_id, updated_at, withdrawal_at, profile_url, email, nickname, gender) VALUES (null, 0, 1, '2025-04-10 12:16:45', 4210895928, null, null, 'http://img1.kakaocdn.net/thumb/R640x640.q70/?fname=http://t1.kakaocdn.net/account_images/default_profile.jpeg', 'dnwntjs009@naver.com', '김시원', null);
