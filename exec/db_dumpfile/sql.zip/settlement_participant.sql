create table settlement_participant
(
    expense_participant_id bigint auto_increment
        primary key,
    created_at             datetime(6) null,
    updated_at             datetime(6) null,
    expense_id             bigint      null,
    member_member_id       bigint      null,
    constraint FK6wqs1i792ed2bjtn4to0kqhew
        foreign key (expense_id) references expense (expense_id),
    constraint FKml69fgx6sqmr6w6c6hg80fo3
        foreign key (member_member_id) references member (member_id)
);

