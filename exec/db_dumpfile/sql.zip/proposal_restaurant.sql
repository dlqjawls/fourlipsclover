create table proposal_restaurant
(
    proposal_id   int not null,
    restaurant_id int not null,
    constraint FK26s6e88tmxb3od4g5k69bkucs
        foreign key (proposal_id) references locals_proposal (proposal_id),
    constraint FKthgjrh6cp1kd41ka3gvt0kebd
        foreign key (restaurant_id) references restaurant (restaurant_id)
);

