create table category
(
    category_id int          not null
        primary key,
    name        varchar(255) null
);

INSERT INTO fourlipsclover.category (category_id, name) VALUES (1, '음식점');
INSERT INTO fourlipsclover.category (category_id, name) VALUES (2, '카페');
