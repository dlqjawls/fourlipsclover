create table local_certification
(
    certificated           bit                                  null,
    local_certification_id int auto_increment
        primary key,
    certificated_at        datetime(6)                          null,
    expiry_at              datetime(6)                          null,
    member_id              bigint                               null,
    local_region_id        varchar(255)                         null,
    local_grade            enum ('FOUR', 'ONE', 'THREE', 'TWO') not null,
    constraint FK1ugto4gx6is7cg1b99n9xnlux
        foreign key (member_id) references member (member_id),
    constraint FKacvtomqha68vbjectkbtn0f09
        foreign key (local_region_id) references local_region (local_region_id)
);

INSERT INTO fourlipsclover.local_certification (certificated, local_certification_id, certificated_at, expiry_at, member_id, local_region_id, local_grade) VALUES (true, 2, '2025-04-06 15:37:04.356537', '2025-05-06 15:37:04.356547', 3962115782, '2920000000', 'TWO');
INSERT INTO fourlipsclover.local_certification (certificated, local_certification_id, certificated_at, expiry_at, member_id, local_region_id, local_grade) VALUES (true, 3, '2025-04-06 17:21:41.306047', '2025-05-06 17:21:41.306056', 3963528811, '2920000000', 'ONE');
INSERT INTO fourlipsclover.local_certification (certificated, local_certification_id, certificated_at, expiry_at, member_id, local_region_id, local_grade) VALUES (true, 9, '2025-04-07 02:50:45.758772', '2025-05-07 02:50:45.758772', 3971753771, '2920000000', 'TWO');
INSERT INTO fourlipsclover.local_certification (certificated, local_certification_id, certificated_at, expiry_at, member_id, local_region_id, local_grade) VALUES (true, 10, '2025-04-08 14:22:42.763792', '2025-05-08 14:22:42.763803', 3967305143, '2920000000', 'TWO');
INSERT INTO fourlipsclover.local_certification (certificated, local_certification_id, certificated_at, expiry_at, member_id, local_region_id, local_grade) VALUES (true, 11, '2025-04-09 15:47:17.564360', '2025-05-09 15:47:17.564371', 4200022075, '2920000000', 'TWO');
INSERT INTO fourlipsclover.local_certification (certificated, local_certification_id, certificated_at, expiry_at, member_id, local_region_id, local_grade) VALUES (true, 12, '2025-04-10 12:19:08.469979', '2025-05-10 12:19:08.470001', 4210895928, '2920000000', 'ONE');
