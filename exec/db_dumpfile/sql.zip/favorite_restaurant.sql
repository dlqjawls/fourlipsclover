create table favorite_restaurant
(
    favorite_restaurant_id int auto_increment
        primary key,
    created_at             datetime(6) null,
    member_id              bigint      null,
    restaurant_id          int         null,
    constraint FKj6j1sum7rs6fm73mw7j9ducyu
        foreign key (restaurant_id) references restaurant (restaurant_id),
    constraint FKrsxgdgk43qb783cb421y2wous
        foreign key (member_id) references member (member_id)
);

INSERT INTO fourlipsclover.favorite_restaurant (favorite_restaurant_id, created_at, member_id, restaurant_id) VALUES (3, '2025-04-06 15:30:52.876610', 4004582987, null);
INSERT INTO fourlipsclover.favorite_restaurant (favorite_restaurant_id, created_at, member_id, restaurant_id) VALUES (4, '2025-04-06 15:34:38.338754', 4004582987, null);
INSERT INTO fourlipsclover.favorite_restaurant (favorite_restaurant_id, created_at, member_id, restaurant_id) VALUES (5, '2025-04-06 15:37:25.398619', 4004582987, null);
