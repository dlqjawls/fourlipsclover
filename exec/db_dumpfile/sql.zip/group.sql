create table `group`
(
    group_id    int auto_increment
        primary key,
    is_public   bit                                not null,
    created_at  datetime default CURRENT_TIMESTAMP not null,
    member_id   bigint                             not null,
    updated_at  datetime(6)                        null,
    name        varchar(10)                        not null,
    description varchar(20)                        null,
    constraint FK2ukqx3ue5vjf7qnocm6p2hc88
        foreign key (member_id) references member (member_id)
);

INSERT INTO fourlipsclover.`group` (group_id, is_public, created_at, member_id, updated_at, name, description) VALUES (95, false, '2025-04-10 16:00:55', 3962115782, null, '돌산남자들', '시골남자들의 도장깨기');
INSERT INTO fourlipsclover.`group` (group_id, is_public, created_at, member_id, updated_at, name, description) VALUES (100, false, '2025-04-11 03:14:21', 3967305143, null, 'ㅎㅎ', '');
INSERT INTO fourlipsclover.`group` (group_id, is_public, created_at, member_id, updated_at, name, description) VALUES (101, false, '2025-04-11 05:02:46', 4200022075, null, '테스트', '테스트용입니다');
INSERT INTO fourlipsclover.`group` (group_id, is_public, created_at, member_id, updated_at, name, description) VALUES (104, true, '2025-04-11 05:42:06', 3967305143, null, '포트폴리오', '촬영용');
