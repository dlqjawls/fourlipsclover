create table food_category
(
    category_id      int          null,
    food_category_id int          not null
        primary key,
    name             varchar(255) null,
    constraint FKs5eg2saqpvfbag6axyocc4jnm
        foreign key (category_id) references category (category_id)
);

INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 1, '한식');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 2, '중식');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 3, '양식');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 4, '일식');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 5, '아시아음식');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 6, '분식');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 7, '간식');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 8, '술집');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 9, '샐러드');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 10, '치킨');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 11, '패스트푸드');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 12, '샤브샤브');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 13, '뷔페');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 14, '구내식당');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 15, '퓨전요리');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 16, '도시락');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 17, '패밀리레스토랑');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 18, '푸드코트');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (2, 19, '카페/디저트');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 20, '기사식당');
INSERT INTO fourlipsclover.food_category (category_id, food_category_id, name) VALUES (1, 21, '철판요리');
