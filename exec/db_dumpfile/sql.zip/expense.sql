create table expense
(
    expense_id          bigint auto_increment
        primary key,
    created_at          datetime(6) null,
    payment_approval_id bigint      null,
    settlement_id       int         null,
    constraint FK9n2psawnk26e3k2lvqq5mtue2
        foreign key (payment_approval_id) references payment_approvals (id),
    constraint FKow77w4py1f6k4xmegnstetwd8
        foreign key (settlement_id) references settlement (settlement_id)
);

INSERT INTO fourlipsclover.expense (expense_id, created_at, payment_approval_id, settlement_id) VALUES (25, '2025-04-11 02:44:06.520161', 4, 43);
INSERT INTO fourlipsclover.expense (expense_id, created_at, payment_approval_id, settlement_id) VALUES (26, '2025-04-11 02:44:06.530226', 5, 43);
INSERT INTO fourlipsclover.expense (expense_id, created_at, payment_approval_id, settlement_id) VALUES (27, '2025-04-11 02:44:06.538376', 6, 43);
INSERT INTO fourlipsclover.expense (expense_id, created_at, payment_approval_id, settlement_id) VALUES (28, '2025-04-11 02:44:06.546441', 7, 43);
