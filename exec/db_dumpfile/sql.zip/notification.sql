create table notification
(
    is_read    bit                                not null,
    created_at datetime default CURRENT_TIMESTAMP not null,
    id         bigint auto_increment
        primary key,
    member_id  bigint                             not null,
    title      varchar(100)                       not null,
    content    varchar(255)                       not null,
    constraint FK1xep8o2ge7if6diclyyx53v4q
        foreign key (member_id) references member (member_id)
);

INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-07 06:31:48', 1, 3967305143, '그룹 가입 요청', '회원 [임시] 님이 그룹 [47] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-07 06:33:22', 2, 3967305143, '그룹 가입 요청', '회원 [임시] 님이 그룹 [47] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-07 08:05:22', 3, 3967305143, '그룹 가입 요청', '회원 [임시] 님이 그룹 [47] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-07 14:02:26', 4, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [45] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-07 14:04:49', 5, 3967305143, '그룹 가입 요청', '회원 [임시] 님이 그룹 [47] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-07 14:33:03', 6, 3967305143, '그룹 가입 요청', '회원 [임시] 님이 그룹 [47] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-07 16:17:00', 7, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [51] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-08 03:09:46', 8, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [45] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-08 03:10:25', 9, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [45] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-08 03:10:42', 10, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [45] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-09 02:29:03', 11, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [58] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-09 02:29:34', 12, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [58] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-09 17:08:24', 13, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [58] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 00:25:56', 14, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [58] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 00:26:46', 15, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [58] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 00:27:18', 16, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [58] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 01:10:07', 17, 4200022075, '그룹 가입 요청', '회원 [임시] 님이 그룹 [61] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 01:10:13', 18, 4200022075, '그룹 가입 요청', '회원 [임시] 님이 그룹 [61] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 01:16:46', 19, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [88] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 01:17:08', 20, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [88] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 02:42:47', 21, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [88] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 02:43:51', 22, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [88] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 23:45:52', 23, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [95] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-10 23:46:06', 24, 3962115782, '그룹 가입 요청', '회원 [임시] 님이 그룹 [95] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-11 05:03:42', 25, 4200022075, '그룹 가입 요청', '회원 [임시] 님이 그룹 [101] 가입을 요청하였습니다.');
INSERT INTO fourlipsclover.notification (is_read, created_at, id, member_id, title, content) VALUES (false, '2025-04-11 05:03:58', 26, 4200022075, '그룹 가입 요청', '회원 [임시] 님이 그룹 [101] 가입을 요청하였습니다.');
