create table plan_notice
(
    is_important   bit                                                         not null,
    plan_id        int                                                         not null,
    plan_notice_id int auto_increment
        primary key,
    created_at     datetime default CURRENT_TIMESTAMP                          not null,
    creator_id     bigint                                                      not null,
    updated_at     datetime(6)                                                 null,
    content        varchar(30)                                                 not null,
    color          enum ('BLUE', 'GREEN', 'ORANGE', 'RED', 'VIOLET', 'YELLOW') not null,
    constraint FK7npgv0rr6l1i03jtu0girewwg
        foreign key (plan_id) references plan (plan_id),
    constraint FKouort6gev10isca4p96v55jpn
        foreign key (creator_id) references member (member_id)
);

INSERT INTO fourlipsclover.plan_notice (is_important, plan_id, plan_notice_id, created_at, creator_id, updated_at, content, color) VALUES (true, 42, 23, '2025-04-11 01:45:42', 3962115782, null, '늦지마라!!', 'RED');
INSERT INTO fourlipsclover.plan_notice (is_important, plan_id, plan_notice_id, created_at, creator_id, updated_at, content, color) VALUES (true, 46, 24, '2025-04-11 05:45:04', 3967305143, null, '숙소는 광안리', 'GREEN');
INSERT INTO fourlipsclover.plan_notice (is_important, plan_id, plan_notice_id, created_at, creator_id, updated_at, content, color) VALUES (true, 46, 25, '2025-04-11 05:45:16', 3967305143, null, '준비물 충전기 필수', 'YELLOW');
INSERT INTO fourlipsclover.plan_notice (is_important, plan_id, plan_notice_id, created_at, creator_id, updated_at, content, color) VALUES (false, 46, 26, '2025-04-11 05:45:32', 3967305143, null, '톤쇼우 가야해', 'RED');
INSERT INTO fourlipsclover.plan_notice (is_important, plan_id, plan_notice_id, created_at, creator_id, updated_at, content, color) VALUES (false, 42, 27, '2025-04-11 06:52:41', 3962115782, null, '조용', 'GREEN');
