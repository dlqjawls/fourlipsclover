create table `match`
(
    guide_request_form_id int                                                   not null,
    match_id              int auto_increment
        primary key,
    region_id             int                                                   not null,
    created_at            datetime default CURRENT_TIMESTAMP                    not null,
    guide_id              bigint                                                not null,
    member_id             bigint                                                not null,
    updated_at            datetime(6)                                           null,
    partner_order_id      varchar(255)                                          null,
    status                enum ('CANCELED', 'CONFIRMED', 'PENDING', 'REJECTED') not null,
    constraint UK8qwka2b1l74isvwamafw75lif
        unique (guide_request_form_id),
    constraint FK5tuw617r5140h9ti93jg428b5
        foreign key (guide_request_form_id) references guide_request_form (guide_request_form_id),
    constraint FK8xefyxqvo7j6b68i96hocrgg8
        foreign key (region_id) references region (region_id),
    constraint FKcj1icickd4jli2tjg852jlo8c
        foreign key (guide_id) references member (member_id)
);

INSERT INTO fourlipsclover.`match` (guide_request_form_id, match_id, region_id, created_at, guide_id, member_id, updated_at, partner_order_id, status) VALUES (93, 90, 29, '2025-04-11 03:08:28', 3967305143, 3962115782, '2025-04-11 03:09:41.036129', '1ea30e18-77dd-42cd-a63f-826220007569', 'CONFIRMED');
INSERT INTO fourlipsclover.`match` (guide_request_form_id, match_id, region_id, created_at, guide_id, member_id, updated_at, partner_order_id, status) VALUES (94, 91, 29, '2025-04-11 05:06:10', 3967305143, 4200022075, '2025-04-11 05:28:10.298693', '2e3a38aa-09e3-49f2-936e-d13393f56efc', 'CONFIRMED');
INSERT INTO fourlipsclover.`match` (guide_request_form_id, match_id, region_id, created_at, guide_id, member_id, updated_at, partner_order_id, status) VALUES (95, 92, 29, '2025-04-11 06:54:03', 3967305143, 3962115782, '2025-04-11 06:54:13.943522', '067c681f-1621-4897-a833-2c43bfc64d69', 'CONFIRMED');
