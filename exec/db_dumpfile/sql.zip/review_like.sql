create table review_like
(
    review_id   int                      not null,
    member_id   bigint                   not null,
    like_status enum ('DISLIKE', 'LIKE') null,
    primary key (review_id, member_id),
    constraint FKf19ep4u0vm5vietilw2kp9jo2
        foreign key (member_id) references member (member_id),
    constraint FKqhfsmngfboq6epp9af8lmegqc
        foreign key (review_id) references reviews (review_id)
);

INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (1, 3962115782, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (2, 4004582987, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (3, 3962115782, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (3, 4004582987, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (28, 4004582987, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (52, 3971753771, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (79, 4004582987, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (91, 3962115782, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (143, 4200022075, 'LIKE');
INSERT INTO fourlipsclover.review_like (review_id, member_id, like_status) VALUES (145, 4210895928, 'LIKE');
