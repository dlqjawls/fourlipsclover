create table match_tag
(
    match_tag_id bigint auto_increment
        primary key,
    match_id     int    not null,
    tag_id       bigint not null,
    constraint FK5rds66cogeekb7l98me35c8wn
        foreign key (tag_id) references tag (tag_id),
    constraint FKdn1iu522emrwtss6cx3yu45e
        foreign key (match_id) references `match` (match_id)
);

INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (91, 90, 1);
INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (92, 90, 6);
INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (93, 90, 58);
INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (94, 91, 15);
INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (95, 91, 21);
INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (96, 91, 40);
INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (97, 92, 2);
INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (98, 92, 6);
INSERT INTO fourlipsclover.match_tag (match_tag_id, match_id, tag_id) VALUES (99, 92, 52);
