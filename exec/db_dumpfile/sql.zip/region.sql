create table region
(
    region_id int          not null
        primary key,
    name      varchar(255) null
);

INSERT INTO fourlipsclover.region (region_id, name) VALUES (11, '서울특별시');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (26, '부산광역시');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (27, '대구광역시');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (28, '인천광역시');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (29, '광주광역시');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (30, '대전광역시');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (31, '울산광역시');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (36, '세종특별자치시');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (41, '경기도');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (42, '강원도');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (43, '충청북도');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (44, '충청남도');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (45, '전라북도');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (46, '전라남도');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (47, '경상북도');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (48, '경상남도');
INSERT INTO fourlipsclover.region (region_id, name) VALUES (50, '제주특별자치도');
