create table plan
(
    end_date     date                               not null,
    group_id     int                                not null,
    plan_id      int auto_increment
        primary key,
    start_date   date                               not null,
    created_at   datetime default CURRENT_TIMESTAMP not null,
    treasurer_id bigint                             not null,
    updated_at   datetime(6)                        null,
    description  text                               not null,
    title        varchar(255)                       not null,
    constraint FK5yuqpu0bfriyk0rkphff9r667
        foreign key (group_id) references `group` (group_id)
);

INSERT INTO fourlipsclover.plan (end_date, group_id, plan_id, start_date, created_at, treasurer_id, updated_at, description, title) VALUES ('2025-04-20', 95, 42, '2025-04-19', '2025-04-11 01:39:45', 3962115782, null, '', '싸피 광주캠 탐방');
INSERT INTO fourlipsclover.plan (end_date, group_id, plan_id, start_date, created_at, treasurer_id, updated_at, description, title) VALUES ('2025-04-19', 100, 44, '2025-04-17', '2025-04-11 03:14:30', 3967305143, null, '', 'ㅋㅋ');
INSERT INTO fourlipsclover.plan (end_date, group_id, plan_id, start_date, created_at, treasurer_id, updated_at, description, title) VALUES ('2025-04-17', 101, 45, '2025-04-15', '2025-04-11 05:03:10', 4200022075, null, '', '음');
INSERT INTO fourlipsclover.plan (end_date, group_id, plan_id, start_date, created_at, treasurer_id, updated_at, description, title) VALUES ('2025-04-25', 104, 46, '2025-04-22', '2025-04-11 05:44:13', 3967305143, null, '', '부산여행');
