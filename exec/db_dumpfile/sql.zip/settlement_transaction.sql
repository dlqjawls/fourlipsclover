create table settlement_transaction
(
    settlement_transaction_id bigint auto_increment
        primary key,
    created_at                datetime(6)                                         null,
    sent_at                   datetime(6)                                         null,
    transaction_status        enum ('CANCELED', 'COMPLETED', 'FAILED', 'PENDING') null,
    payee_id                  bigint                                              null,
    payer_id                  bigint                                              null,
    settlement_id             int                                                 null,
    cost                      int                                                 null,
    constraint FK9e49erodxrt5ydr9jpprgxc0l
        foreign key (payee_id) references member (member_id),
    constraint FKjjw3d280ubld23icw7q633w39
        foreign key (payer_id) references member (member_id),
    constraint FKpafmy6cdn77gdpby9dbb6wga8
        foreign key (settlement_id) references settlement (settlement_id)
);

INSERT INTO fourlipsclover.settlement_transaction (settlement_transaction_id, created_at, sent_at, transaction_status, payee_id, payer_id, settlement_id, cost) VALUES (29, '2025-04-11 03:12:26.886394', null, 'COMPLETED', 3962115782, 3971753771, 43, 76668);
INSERT INTO fourlipsclover.settlement_transaction (settlement_transaction_id, created_at, sent_at, transaction_status, payee_id, payer_id, settlement_id, cost) VALUES (30, '2025-04-11 03:12:26.888233', null, 'COMPLETED', 3962115782, 4200022075, 43, 76668);
