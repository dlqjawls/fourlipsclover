create table plan_member
(
    plan_id   int          not null,
    joined_at datetime(6)  not null,
    member_id bigint       not null,
    role      varchar(255) not null,
    primary key (plan_id, member_id),
    constraint FKpqh5tu72ee201rj530c2gnauq
        foreign key (plan_id) references plan (plan_id),
    constraint FKs7d0cwlf21lg23lt5n74evhnv
        foreign key (member_id) references member (member_id)
);

INSERT INTO fourlipsclover.plan_member (plan_id, joined_at, member_id, role) VALUES (42, '2025-04-11 01:39:44.912739', 3962115782, 'Treasurer');
INSERT INTO fourlipsclover.plan_member (plan_id, joined_at, member_id, role) VALUES (42, '2025-04-11 02:18:29.045856', 3971753771, 'Participant');
INSERT INTO fourlipsclover.plan_member (plan_id, joined_at, member_id, role) VALUES (42, '2025-04-11 01:39:44.918597', 4200022075, 'Participant');
INSERT INTO fourlipsclover.plan_member (plan_id, joined_at, member_id, role) VALUES (44, '2025-04-11 03:14:30.324009', 3967305143, 'Treasurer');
INSERT INTO fourlipsclover.plan_member (plan_id, joined_at, member_id, role) VALUES (45, '2025-04-11 05:36:05.502791', 3962115782, 'Participant');
INSERT INTO fourlipsclover.plan_member (plan_id, joined_at, member_id, role) VALUES (45, '2025-04-11 05:03:09.657236', 4200022075, 'Treasurer');
INSERT INTO fourlipsclover.plan_member (plan_id, joined_at, member_id, role) VALUES (46, '2025-04-11 05:44:13.456127', 3967305143, 'Treasurer');
